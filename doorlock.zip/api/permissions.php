<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

header('Content-Type: application/json');
require_once '../includes/config.php';

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {

    case 'GET':
        $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        if ($id) {
            $stmt = $conn->prepare("SELECT * FROM `groups` WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $group = $stmt->get_result()->fetch_assoc();
            if (!$group) {
                http_response_code(404);
                echo json_encode(['error' => 'Group not found']);
            } else {
                echo json_encode(['group' => $group]);
            }
        } else {
            $result = $conn->query("SELECT * FROM `groups` ORDER BY name ASC");
            echo json_encode(['groups' => $result->fetch_all(MYSQLI_ASSOC)]);
        }
        break;

    case 'POST':
        $data = json_decode(file_get_contents('php://input'), true);
        $name = trim($data['name'] ?? '');
        $description = trim($data['description'] ?? '');

        if ($name === '') {
            http_response_code(400);
            echo json_encode(['error' => 'Name is required']);
            exit;
        }

        // Check duplicate name
        $stmt = $conn->prepare("SELECT id FROM `groups` WHERE name = ?");
        $stmt->bind_param("s", $name);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            http_response_code(409);
            echo json_encode(['error' => 'Group name already exists']);
            exit;
        }

        $stmt = $conn->prepare("INSERT INTO `groups` (name, description) VALUES (?, ?)");
        $stmt->bind_param("ss", $name, $description);
        if ($stmt->execute()) {
            $newId = $conn->insert_id;
            http_response_code(201);
            echo json_encode(['success' => true, 'id' => $newId]);
        } else {
            http_response_code(500);
            echo json_encode(['error' => 'Failed to create group']);
        }
        break;

    case 'PUT':
        $data = json_decode(file_get_contents('php://input'), true);
        $id = (int)($data['id'] ?? 0);
        $name = trim($data['name'] ?? '');
        $description = trim($data['description'] ?? '');

        if (!$id || $name === '') {
            http_response_code(400);
            echo json_encode(['error' => 'id and name are required']);
            exit;
        }

        // Check duplicate name (excluding self)
        $stmt = $conn->prepare("SELECT id FROM `groups` WHERE name = ? AND id != ?");
        $stmt->bind_param("si", $name, $id);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            http_response_code(409);
            echo json_encode(['error' => 'Group name already exists']);
            exit;
        }

        $stmt = $conn->prepare("UPDATE `groups` SET name = ?, description = ? WHERE id = ?");
        $stmt->bind_param("ssi", $name, $description, $id);
        if ($stmt->execute()) {
            if ($stmt->affected_rows === 0) {
                http_response_code(404);
                echo json_encode(['error' => 'Group not found']);
            } else {
                echo json_encode(['success' => true]);
            }
        } else {
            http_response_code(500);
            echo json_encode(['error' => 'Failed to update group']);
        }
        break;

    case 'DELETE':
        $data = json_decode(file_get_contents('php://input'), true);
        $id = (int)($data['id'] ?? $_GET['id'] ?? 0);

        if (!$id) {
            http_response_code(400);
            echo json_encode(['error' => 'id is required']);
            exit;
        }

        // CASCADE در دیتابیس تعریف شده، پس حذف group به تنهایی کافی است
        $stmt = $conn->prepare("DELETE FROM `groups` WHERE id = ?");
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            if ($stmt->affected_rows === 0) {
                http_response_code(404);
                echo json_encode(['error' => 'Group not found']);
            } else {
                echo json_encode(['success' => true]);
            }
        } else {
            http_response_code(500);
            echo json_encode(['error' => 'Failed to delete group']);
        }
        break;

    default:
        http_response_code(405);
        echo json_encode(['error' => 'Method not allowed']);
}
